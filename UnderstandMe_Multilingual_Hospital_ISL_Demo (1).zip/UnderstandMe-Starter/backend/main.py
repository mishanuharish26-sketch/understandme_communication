from datetime import datetime, timedelta, timezone
from pathlib import Path
import secrets
import sqlite3
from typing import Literal

from fastapi import FastAPI, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

DB_PATH = Path(__file__).resolve().parent / "understandme.db"
app = FastAPI(title="UnderstandMe Demo API", version="0.1.0")

# Open CORS is acceptable only for this local hackathon demo. Tighten it before deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


def connect_db():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def init_db():
    with connect_db() as db:
        db.execute(
            """CREATE TABLE IF NOT EXISTS profiles (
                token TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                preferred_language TEXT NOT NULL,
                accessibility_notes TEXT NOT NULL,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                revoked INTEGER NOT NULL DEFAULT 0
            )"""
        )
        db.execute(
            """CREATE TABLE IF NOT EXISTS hospital_reports (
                report_id TEXT PRIMARY KEY,
                patient_name TEXT NOT NULL,
                age INTEGER,
                language TEXT NOT NULL,
                severity TEXT NOT NULL,
                duration TEXT NOT NULL,
                symptoms TEXT NOT NULL,
                allergies TEXT NOT NULL,
                notes TEXT NOT NULL,
                communication_method TEXT NOT NULL,
                created_at TEXT NOT NULL
            )"""
        )


init_db()


class ProfileCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    preferred_language: str = Field(default="English", max_length=40)
    accessibility_notes: str = Field(default="", max_length=500)
    expires_in_minutes: int = Field(default=30, ge=1, le=1440)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/api/profiles", status_code=201)
def create_profile(payload: ProfileCreate):
    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(minutes=payload.expires_in_minutes)
    token = secrets.token_urlsafe(32)
    with connect_db() as db:
        db.execute(
            "INSERT INTO profiles(token, name, preferred_language, accessibility_notes, created_at, expires_at, revoked) VALUES (?, ?, ?, ?, ?, ?, 0)",
            (
                token,
                payload.name.strip(),
                payload.preferred_language.strip() or "English",
                payload.accessibility_notes.strip(),
                now.isoformat(),
                expires_at.isoformat(),
            ),
        )
    return {"token": token, "created_at": now.isoformat(), "expires_at": expires_at.isoformat()}


class HospitalReportCreate(BaseModel):
    patient_name: str = Field(default="Not provided", max_length=80)
    age: int | None = Field(default=None, ge=0, le=120)
    language: str = Field(default="Tamil", min_length=1, max_length=20)
    severity: Literal["Mild", "Moderate", "Severe", "Emergency"] = "Moderate"
    duration: str = Field(default="", max_length=120)
    symptoms: str = Field(min_length=1, max_length=2000)
    allergies: str = Field(default="", max_length=500)
    notes: str = Field(default="", max_length=1500)
    communication_method: str = Field(default="Accessible phrase buttons / keyboard input; camera hand tracking only", max_length=100)


@app.post("/api/reports", status_code=201)
def create_hospital_report(payload: HospitalReportCreate):
    """Save a fictional/demo hospital communication report locally.

    This endpoint is intentionally unauthenticated for the hackathon prototype only.
    Do not deploy it for real patient data without authentication, authorisation,
    encryption, retention controls, audit logging, and a clinical privacy review.
    """
    now = datetime.now(timezone.utc).isoformat()
    report_id = secrets.token_urlsafe(9)
    with connect_db() as db:
        db.execute(
            """INSERT INTO hospital_reports
            (report_id, patient_name, age, language, severity, duration, symptoms,
             allergies, notes, communication_method, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                report_id,
                payload.patient_name.strip() or "Not provided",
                payload.age,
                payload.language.strip() or "Tamil",
                payload.severity,
                payload.duration.strip(),
                payload.symptoms.strip(),
                payload.allergies.strip(),
                payload.notes.strip(),
                payload.communication_method.strip() or "Accessible input",
                now,
            ),
        )
    return {"report_id": report_id, "created_at": now, "status": "saved_demo"}


@app.get("/api/reports/{report_id}")
def get_hospital_report(report_id: str):
    """Fetch one report in this local demo database. Protect this endpoint before real use."""
    with connect_db() as db:
        row = db.execute(
            "SELECT report_id, patient_name, age, language, severity, duration, symptoms, allergies, notes, communication_method, created_at FROM hospital_reports WHERE report_id = ?",
            (report_id,),
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Report not found.")
    return {key: row[key] for key in row.keys()}



def active_profile(token: str):
    with connect_db() as db:
        row = db.execute(
            "SELECT token, name, preferred_language, accessibility_notes, created_at, expires_at, revoked FROM profiles WHERE token = ?",
            (token,),
        ).fetchone()
    if row is None or row["revoked"]:
        raise HTTPException(status_code=410, detail="This QR link is invalid, expired, or revoked.")
    expiry = datetime.fromisoformat(row["expires_at"])
    if expiry <= datetime.now(timezone.utc):
        raise HTTPException(status_code=410, detail="This QR link is invalid, expired, or revoked.")
    return row


@app.get("/api/profiles/{token}")
def get_profile(token: str):
    row = active_profile(token)
    return {
        "name": row["name"],
        "preferred_language": row["preferred_language"],
        "accessibility_notes": row["accessibility_notes"],
        "created_at": row["created_at"],
        "expires_at": row["expires_at"],
    }


@app.delete("/api/profiles/{token}", status_code=204)
def revoke_profile(token: str):
    with connect_db() as db:
        row = db.execute("SELECT token FROM profiles WHERE token = ?", (token,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Profile not found.")
        db.execute("UPDATE profiles SET revoked = 1 WHERE token = ?", (token,))
    return Response(status_code=204)
