from fastapi.testclient import TestClient
from main import app

client = TestClient(app)


def test_create_read_and_revoke_profile():
    created = client.post(
        "/api/profiles",
        json={
            "name": "Demo Person",
            "preferred_language": "English",
            "accessibility_notes": "Please read amounts aloud.",
            "expires_in_minutes": 10,
        },
    )
    assert created.status_code == 201
    token = created.json()["token"]

    fetched = client.get(f"/api/profiles/{token}")
    assert fetched.status_code == 200
    assert fetched.json()["name"] == "Demo Person"

    revoked = client.delete(f"/api/profiles/{token}")
    assert revoked.status_code == 204
    denied = client.get(f"/api/profiles/{token}")
    assert denied.status_code == 410


def test_create_hospital_report():
    response = client.post(
        "/api/reports",
        json={
            "patient_name": "Demo Patient",
            "age": 25,
            "language": "Tamil",
            "severity": "Moderate",
            "duration": "Since morning",
            "symptoms": "I have a headache; I need a doctor",
            "allergies": "Not known",
            "notes": "Fictional hackathon test",
            "communication_method": "ISL-assisted / accessible phrase input",
        },
    )
    assert response.status_code == 201
    report_id = response.json()["report_id"]
    assert response.json()["status"] == "saved_demo"

    fetched = client.get(f"/api/reports/{report_id}")
    assert fetched.status_code == 200
    assert fetched.json()["symptoms"] == "I have a headache; I need a doctor"


def test_report_rejects_empty_symptoms():
    response = client.post("/api/reports", json={"symptoms": ""})
    assert response.status_code == 422
