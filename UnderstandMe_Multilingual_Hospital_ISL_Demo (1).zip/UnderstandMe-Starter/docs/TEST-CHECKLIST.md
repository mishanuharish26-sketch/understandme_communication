# UnderstandMe — Test Checklist

Test with fictional information only. Mark **Pass**, **Fail**, or **Not tested** and record the device/browser and evidence.

| ID | Test | Expected result | Actual result |
|---|---|---|---|
| T01 | Start backend and open `/health` | API returns `{"status":"ok"}` | Not tested |
| T02 | Start frontend | UnderstandMe home page appears and API badge shows online | Not tested |
| T03 | Create a fictional accessibility profile | QR appears with an expiry time | Not tested |
| T04 | Scan the QR on a second device on the same Wi-Fi | Staff profile opens without a login screen | Not tested |
| T05 | Press “Read profile aloud” | Browser speaks the visible profile content | Not tested |
| T06 | Create a profile with 1-minute expiry and wait until it expires | Staff page denies access after refresh | Not tested |
| T07 | Revoke a newly created profile | Staff page denies access after refresh | Not tested |
| T08 | Disconnect/stop the backend and try loading the profile | App shows an understandable error, not a blank page | Not tested |
| T09 | Use keyboard Tab and Enter on main controls | Focus is visible; controls are usable by keyboard | Not tested |
| T10 | Use “Read bill aloud” | Invoice total of ₹390 is spoken | Not tested |
| T11 | Click “Confirm demo payment” | Clear message confirms no payment was taken | Not tested |
| T12 | Add a medicine reminder label and time | Entry appears on page; no real notification is claimed | Not tested |
| T13 | Open the QR link after revoking | Access is denied with a clear message | Not tested |
| T14 | Run frontend build | `npm run build` completes successfully | Not tested |
| T15 | Run backend test | `py -m pytest -q` passes | Not tested |

## Two-device demo evidence

- Laptop model/browser:
- Phone model/browser:
- Same trusted Wi-Fi? Yes / No
- Frontend URL used:
- Backend health check:
- QR profile open result:
- Voice playback result:
- Revocation result:
- Expiry result:
- Screenshot/video file names:
- Known failures or limitations:


## Hospital report / ISL camera module

- [ ] Hospital Report is the default tab.
- [ ] Camera permission accepted: preview appears and hand-landmark overlays update when hands are visible.
- [ ] Camera permission denied or MediaPipe CDN blocked: an error is shown and phrase tiles remain usable.
- [ ] Phrase tile appends readable text to Symptoms / message.
- [ ] Read report aloud works where browser text-to-speech is supported.
- [ ] Empty symptoms cannot be submitted.
- [ ] Valid report POST returns 201, report ID, timestamp, and `saved_demo` status.
- [ ] GET the returned report ID returns the submitted symptom text.
- [ ] Unknown report ID returns 404.
- [ ] UI does not claim automatic ISL translation or clinical diagnosis.
- [ ] Only fictional data is used.
