# 3-Minute Demo Script

**0:00–0:25 — Problem**  
People who benefit from spoken or simplified information can struggle to access profiles and billing details quickly. Explain that this is a prototype that demonstrates accessible interaction, not a production service.

**0:25–1:10 — Temporary QR profile**  
Create a fictional visitor profile, show its QR code, and scan it with a second device. Explain that the backend checks a random token, expiry, and revocation status. Press “Read profile aloud.”

**1:10–1:45 — Security check**  
Revoke a profile and refresh its staff page to show access denial. If the 1-minute expiry test has actually been completed, report the result; do not claim an untested expiry test passed.

**1:45–2:20 — Accessible bill**  
Show the fictional invoice, read it aloud, and point out the ₹390 total. Click the demo payment button and clearly state no real payment was processed.

**2:20–2:40 — Medicine reminder concept**  
Save a label and time to demonstrate the interface. State that this prototype does not send notifications or provide dosage/medical advice.

**2:40–3:00 — Limitations and next steps**  
Explain that the current prototype requires the demo services to be running, browser speech support varies, and the application needs HTTPS, stricter CORS, security review, and real notification/payment integrations before any real-world use.


## Hospital communication report

1. Open Hospital Report and explain that the primary user may be a patient who cannot speak.
2. Start camera hand tracking and show the landmark overlay. State clearly that this build tracks hands but does not yet infer ISL word meaning.
3. Tap “I have pain” or “I need a doctor” as an accessible non-speaking input fallback.
4. Review the report, read it aloud, and submit. Show the returned report ID from the local demo API.
5. Explain that the next ML milestone uses a labelled emergency ISL vocabulary and a trained temporal classifier; low-confidence gestures must never be silently converted to a medical statement.
