# Hospital-focused ISL recognition: next steps

## What works in this updated starter

- Browser camera preview and MediaPipe Hands landmark overlay, where CDN access and camera permission are available.
- Accessible phrase buttons and keyboard entry for a patient who cannot speak.
- Read report aloud, review report fields, submit to FastAPI, save in a local SQLite database, and receive a report ID.
- The frontend clearly tells the user that landmarks are not semantic sign recognition.

## What is not implemented yet

The project does not include a trained ISL classifier. MediaPipe hand landmarks alone do not provide the sign's meaning. Do not map generic gestures such as an open palm or thumbs-up to medical phrases and do not claim automatic translation until the classifier is trained and tested.

## Better initial training vocabulary

For a hospital reception/emergency demo, begin with these labels from the published emergency ISL dataset:

- pain
- help
- doctor
- call
- accident
- hot
- lose
- thief

The publication describes 824 video samples across those eight words. Source page: https://data.mendeley.com/datasets/2vfdm42337/1. Paper: https://pmc.ncbi.nlm.nih.gov/articles/PMC7378574/.

INCLUDE is a separate broad isolated-sign dataset containing metadata for thousands of clips; it is useful for broad vocabulary but don't assume every medical term is present in the small INCLUDE-50 subset. https://huggingface.co/datasets/ai4bharat/INCLUDE

## Training/integration sequence

1. Download and review the emergency-sign dataset, and confirm terms/licence and attribution requirements.
2. Build a labelled train/validation/test split by signer so clips from one signer do not leak across splits.
3. Extract per-frame hand landmarks with MediaPipe from each labelled clip and normalise coordinates and sequence length.
4. Train a temporal classifier (for example, a small 1D CNN or BiLSTM) on training sequences; report held-out signer performance and confidence calibration.
5. Add a backend inference endpoint that accepts a sequence, returns `label`, `confidence`, and `requires_confirmation`.
6. Display predictions as suggestions only. Require patient confirmation, and preserve a manual phrase/keyboard alternative.
7. Test different lighting, skin tones, camera positions, motion speeds, and signs not in the supported vocabulary. Unknown/low-confidence gestures should trigger “Please repeat or choose a phrase,” never a guessed symptom.

This starter's report endpoint is an unauthenticated local demo. Do not use real patient data or put it on a public server until security and clinical privacy requirements are implemented and reviewed.
