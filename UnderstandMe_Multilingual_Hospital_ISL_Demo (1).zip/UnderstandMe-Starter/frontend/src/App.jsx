import { useEffect, useMemo, useRef, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';

const LANGUAGES = [
  { name: 'English', locale: 'en-IN' }, { name: 'தமிழ் (Tamil)', value: 'Tamil', locale: 'ta-IN' },
  { name: 'हिन्दी (Hindi)', value: 'Hindi', locale: 'hi-IN' }, { name: 'తెలుగు (Telugu)', value: 'Telugu', locale: 'te-IN' },
  { name: 'ಕನ್ನಡ (Kannada)', value: 'Kannada', locale: 'kn-IN' }, { name: 'മലയാളം (Malayalam)', value: 'Malayalam', locale: 'ml-IN' },
  { name: 'বাংলা (Bengali)', value: 'Bengali', locale: 'bn-IN' }, { name: 'मराठी (Marathi)', value: 'Marathi', locale: 'mr-IN' },
  { name: 'ગુજરાતી (Gujarati)', value: 'Gujarati', locale: 'gu-IN' }, { name: 'ਪੰਜਾਬੀ (Punjabi)', value: 'Punjabi', locale: 'pa-IN' },
  { name: 'ଓଡ଼ିଆ (Odia)', value: 'Odia', locale: 'or-IN' }, { name: 'অসমীয়া (Assamese)', value: 'Assamese', locale: 'as-IN' },
  { name: 'اردو (Urdu)', value: 'Urdu', locale: 'ur-IN' }, { name: 'संस्कृतम् (Sanskrit)', value: 'Sanskrit', locale: 'sa-IN' },
  { name: 'Other / type language', value: 'Other', locale: 'en-IN' },
];
const I18N = {
  English: { hospital:'Hospital report', intro:'Designed for a patient who cannot speak. Choose a language; camera tracking detects hands, while automatic sign-to-text needs a trained ISL model.', camera:'Start camera & hand tracking', stop:'Stop camera', cameraTitle:'Hand-tracking preview', cameraSub:'Start the camera to track hand landmarks', quick:'Quick hospital phrases', quickHelp:'Tap the message the patient wants to communicate. These are fallback inputs, not AI-recognised signs.', clear:'Clear symptoms', speech:'Optional speech input', review:'Review before submission', details:'Patient details & symptoms', fictional:'Use fictional data for the hackathon demo.', patient:'Patient name (optional)', age:'Age (optional)', language:'Preferred language', symptoms:'Symptoms / message *', symptomPlaceholder:'Choose a phrase or type the patient’s message…', urgency:'Urgency selected', duration:'How long?', durationPlaceholder:'e.g. since this morning', allergies:'Known allergies (optional)', allergyPlaceholder:'Unknown / none reported / details', notes:'Additional notes (optional)', notesPlaceholder:'Any other details the patient wants to communicate', read:'Read report aloud', submit:'Confirm & submit report', saving:'Saving…', privacy:'Privacy: camera frames are processed in this browser and are not uploaded or stored by this app.', emergency:'Emergency note', pain:'I have pain', headache:'I have a headache', stomach:'I have stomach pain', fever:'I have fever', dizzy:'I feel dizzy', nausea:'I feel nauseous', help:'I need help', doctor:'I need a doctor', breathing:'I have difficulty breathing', allergy:'I have an allergy', water:'I need water', unwell:'I feel unwell' },
  Tamil: { hospital:'மருத்துவமனை அறிக்கை', intro:'பேச முடியாத நோயாளிக்கானது. மொழியைத் தேர்ந்தெடுக்கவும். கேமரா கைகளைப் பின்தொடரும்; சைகை-உரை மாற்றத்திற்கு பயிற்சி பெற்ற ISL மாதிரி தேவை.', camera:'கேமரா மற்றும் கை கண்காணிப்பைத் தொடங்கு', stop:'கேமராவை நிறுத்து', cameraTitle:'கை கண்காணிப்பு முன்னோட்டம்', cameraSub:'கை அசைவுகளைப் பின்தொடர கேமராவைத் தொடங்கவும்', quick:'விரைவு மருத்துவமனைச் செய்திகள்', quickHelp:'நோயாளி தெரிவிக்க விரும்பும் செய்தியைத் தேர்ந்தெடுக்கவும். இவை மாற்று உள்ளீடுகள்; AI அடையாளம் கண்ட சைகைகள் அல்ல.', clear:'அறிகுறிகளை அழி', speech:'விருப்ப குரல் உள்ளீடு', review:'சமர்ப்பிக்கும் முன் சரிபார்க்கவும்', details:'நோயாளர் விவரங்கள் மற்றும் அறிகுறிகள்', fictional:'ஹேக்கத்தான் காட்சிக்காக கற்பனைத் தகவல்களைப் பயன்படுத்தவும்.', patient:'நோயாளர் பெயர் (விருப்பம்)', age:'வயது (விருப்பம்)', language:'விரும்பும் மொழி', symptoms:'அறிகுறிகள் / செய்தி *', symptomPlaceholder:'ஒரு செய்தியைத் தேர்ந்தெடுக்கவும் அல்லது தட்டச்சு செய்யவும்…', urgency:'அவசர நிலை', duration:'எவ்வளவு நேரமாக?', durationPlaceholder:'எ.கா. இன்று காலை முதல்', allergies:'ஒவ்வாமைகள் (விருப்பம்)', allergyPlaceholder:'தெரியாது / எதுவும் இல்லை / விவரங்கள்', notes:'கூடுதல் குறிப்புகள் (விருப்பம்)', notesPlaceholder:'நோயாளர் தெரிவிக்க விரும்பும் பிற விவரங்கள்', read:'அறிக்கையை ஒலியாக வாசி', submit:'உறுதிசெய்து சமர்ப்பி', saving:'சேமிக்கிறது…', privacy:'தனியுரிமை: கேமரா படங்கள் இந்த உலாவியிலேயே செயலாக்கப்படும்; பதிவேற்றப்படவோ சேமிக்கப்படவோ மாட்டாது.', emergency:'அவசரக் குறிப்பு', pain:'எனக்கு வலி உள்ளது', headache:'எனக்கு தலைவலி', stomach:'எனக்கு வயிற்றுவலி', fever:'எனக்கு காய்ச்சல்', dizzy:'எனக்கு தலைசுற்றுகிறது', nausea:'எனக்கு குமட்டல்', help:'எனக்கு உதவி தேவை', doctor:'எனக்கு மருத்துவர் தேவை', breathing:'எனக்கு மூச்சுவிட சிரமம்', allergy:'எனக்கு ஒவ்வாமை உள்ளது', water:'எனக்கு தண்ணீர் தேவை', unwell:'எனக்கு உடல்நலம் சரியில்லை' },
  Hindi: { hospital:'अस्पताल रिपोर्ट', intro:'बोल न पाने वाले मरीज के लिए। भाषा चुनें। कैमरा हाथों को ट्रैक करता है; संकेतों को पाठ में बदलने के लिए प्रशिक्षित ISL मॉडल चाहिए।', camera:'कैमरा और हैंड ट्रैकिंग शुरू करें', stop:'कैमरा बंद करें', cameraTitle:'हाथ ट्रैकिंग पूर्वावलोकन', cameraSub:'हाथों को ट्रैक करने के लिए कैमरा शुरू करें', quick:'अस्पताल के त्वरित वाक्य', quickHelp:'मरीज जो संदेश देना चाहता है उसे चुनें। ये वैकल्पिक इनपुट हैं, AI द्वारा पहचाने गए संकेत नहीं।', clear:'लक्षण हटाएँ', speech:'वैकल्पिक आवाज़ इनपुट', review:'जमा करने से पहले समीक्षा करें', details:'मरीज का विवरण और लक्षण', fictional:'हैकाथॉन डेमो के लिए काल्पनिक जानकारी का उपयोग करें।', patient:'मरीज का नाम (वैकल्पिक)', age:'उम्र (वैकल्पिक)', language:'पसंदीदा भाषा', symptoms:'लक्षण / संदेश *', symptomPlaceholder:'वाक्य चुनें या मरीज का संदेश लिखें…', urgency:'चुनी गई गंभीरता', duration:'कब से?', durationPlaceholder:'जैसे आज सुबह से', allergies:'ज्ञात एलर्जी (वैकल्पिक)', allergyPlaceholder:'अज्ञात / कोई नहीं / विवरण', notes:'अतिरिक्त नोट (वैकल्पिक)', notesPlaceholder:'मरीज जो अन्य जानकारी देना चाहता है', read:'रिपोर्ट सुनाएँ', submit:'पुष्टि करें और जमा करें', saving:'सहेजा जा रहा है…', privacy:'गोपनीयता: कैमरा फ्रेम इसी ब्राउज़र में संसाधित होते हैं; अपलोड या सहेजे नहीं जाते।', emergency:'आपातकालीन सूचना', pain:'मुझे दर्द है', headache:'मेरे सिर में दर्द है', stomach:'मेरे पेट में दर्द है', fever:'मुझे बुखार है', dizzy:'मुझे चक्कर आ रहे हैं', nausea:'मुझे मतली आ रही है', help:'मुझे मदद चाहिए', doctor:'मुझे डॉक्टर चाहिए', breathing:'मुझे साँस लेने में कठिनाई है', allergy:'मुझे एलर्जी है', water:'मुझे पानी चाहिए', unwell:'मेरी तबीयत ठीक नहीं है' },
  Telugu: { hospital:'ఆసుపత్రి నివేదిక', intro:'మాట్లాడలేని రోగి కోసం. భాషను ఎంచుకోండి. కెమెరా చేతులను ట్రాక్ చేస్తుంది; సంకేతాలను వచనంగా మార్చడానికి శిక్షణ పొందిన ISL మోడల్ అవసరం.', camera:'కెమెరా మరియు చేతి ట్రాకింగ్ ప్రారంభించండి', stop:'కెమెరా ఆపండి', cameraTitle:'చేతి ట్రాకింగ్ ప్రివ్యూ', cameraSub:'చేతి కదలికలను ట్రాక్ చేయడానికి కెమెరాను ప్రారంభించండి', quick:'త్వరిత ఆసుపత్రి వాక్యాలు', quickHelp:'రోగి చెప్పాలనుకున్న సందేశాన్ని ఎంచుకోండి. ఇవి ప్రత్యామ్నాయ ఇన్‌పుట్‌లు; AI గుర్తించిన సంకేతాలు కావు.', clear:'లక్షణాలను తొలగించండి', speech:'ఐచ్ఛిక వాయిస్ ఇన్‌పుట్', review:'సమర్పించే ముందు పరిశీలించండి', details:'రోగి వివరాలు మరియు లక్షణాలు', fictional:'హ్యాకథాన్ డెమో కోసం కల్పిత వివరాలు ఉపయోగించండి.', patient:'రోగి పేరు (ఐచ్ఛికం)', age:'వయస్సు (ఐచ్ఛికం)', language:'ఇష్టమైన భాష', symptoms:'లక్షణాలు / సందేశం *', symptomPlaceholder:'వాక్యాన్ని ఎంచుకోండి లేదా సందేశాన్ని టైప్ చేయండి…', urgency:'ఎంచుకున్న అత్యవసర స్థాయి', duration:'ఎంతకాలంగా?', durationPlaceholder:'ఉదా. ఈ ఉదయం నుంచి', allergies:'తెలిసిన అలర్జీలు (ఐచ్ఛికం)', allergyPlaceholder:'తెలియదు / లేవు / వివరాలు', notes:'అదనపు గమనికలు (ఐచ్ఛికం)', notesPlaceholder:'రోగి తెలియజేయాలనుకునే ఇతర వివరాలు', read:'నివేదికను చదివి వినిపించండి', submit:'నిర్ధారించి సమర్పించండి', saving:'సేవ్ అవుతోంది…', privacy:'గోప్యత: కెమెరా ఫ్రేమ్‌లు ఈ బ్రౌజర్‌లోనే ప్రాసెస్ అవుతాయి; అప్‌లోడ్ లేదా నిల్వ చేయబడవు.', emergency:'అత్యవసర గమనిక', pain:'నాకు నొప్పిగా ఉంది', headache:'నాకు తలనొప్పి ఉంది', stomach:'నాకు కడుపునొప్పి ఉంది', fever:'నాకు జ్వరం ఉంది', dizzy:'నాకు తల తిరుగుతోంది', nausea:'నాకు వాంతి భావన ఉంది', help:'నాకు సహాయం కావాలి', doctor:'నాకు డాక్టర్ కావాలి', breathing:'నాకు శ్వాస తీసుకోవడంలో ఇబ్బంది ఉంది', allergy:'నాకు అలర్జీ ఉంది', water:'నాకు నీరు కావాలి', unwell:'నాకు బాగోలేదు' },
  Malayalam: { hospital:'ആശുപത്രി റിപ്പോർട്ട്', intro:'സംസാരിക്കാൻ കഴിയാത്ത രോഗിക്കായി. ഭാഷ തിരഞ്ഞെടുക്കുക. ക്യാമറ കൈകൾ ട്രാക്ക് ചെയ്യും; ആംഗ്യങ്ങളെ എഴുത്താക്കാൻ പരിശീലിപ്പിച്ച ISL മോഡൽ വേണം.', camera:'ക്യാമറയും കൈ ട്രാക്കിംഗും ആരംഭിക്കുക', stop:'ക്യാമറ നിർത്തുക', cameraTitle:'കൈ ട്രാക്കിംഗ് പ്രിവ്യൂ', cameraSub:'കൈകൾ ട്രാക്ക് ചെയ്യാൻ ക്യാമറ ആരംഭിക്കുക', quick:'വേഗത്തിലുള്ള ആശുപത്രി വാക്യങ്ങൾ', quickHelp:'രോഗി അറിയിക്കാൻ ആഗ്രഹിക്കുന്ന സന്ദേശം തിരഞ്ഞെടുക്കുക. ഇവ പകരം നൽകാവുന്ന ഇൻപുട്ടുകളാണ്; AI തിരിച്ചറിഞ്ഞ ആംഗ്യങ്ങളല്ല.', clear:'ലക്ഷണങ്ങൾ മായ്ക്കുക', speech:'ഐച്ഛിക ശബ്ദ ഇൻപുട്ട്', review:'സമർപ്പിക്കുന്നതിന് മുമ്പ് പരിശോധിക്കുക', details:'രോഗിയുടെ വിവരങ്ങളും ലക്ഷണങ്ങളും', fictional:'ഹാക്കത്തോൺ ഡെമോയ്ക്ക് സാങ്കൽപ്പിക വിവരങ്ങൾ ഉപയോഗിക്കുക.', patient:'രോഗിയുടെ പേര് (ഐച്ഛികം)', age:'പ്രായം (ഐച്ഛികം)', language:'ഇഷ്ടപ്പെട്ട ഭാഷ', symptoms:'ലക്ഷണങ്ങൾ / സന്ദേശം *', symptomPlaceholder:'വാക്യം തിരഞ്ഞെടുക്കുക അല്ലെങ്കിൽ സന്ദേശം ടൈപ്പ് ചെയ്യുക…', urgency:'തിരഞ്ഞെടുത്ത അടിയന്തരത', duration:'എത്ര നാളായി?', durationPlaceholder:'ഉദാ. ഇന്ന് രാവിലെ മുതൽ', allergies:'അറിയാവുന്ന അലർജികൾ (ഐച്ഛികം)', allergyPlaceholder:'അറിയില്ല / ഇല്ല / വിവരങ്ങൾ', notes:'കൂടുതൽ കുറിപ്പുകൾ (ഐച്ഛികം)', notesPlaceholder:'രോഗി അറിയിക്കാൻ ആഗ്രഹിക്കുന്ന മറ്റ് വിവരങ്ങൾ', read:'റിപ്പോർട്ട് ശബ്ദമായി വായിക്കുക', submit:'സ്ഥിരീകരിച്ച് സമർപ്പിക്കുക', saving:'സേവ് ചെയ്യുന്നു…', privacy:'സ്വകാര്യത: ക്യാമറ ഫ്രെയിമുകൾ ഈ ബ്രൗസറിൽ തന്നെ പ്രോസസ്സ് ചെയ്യുന്നു; അപ്‌ലോഡ് ചെയ്യുകയോ സൂക്ഷിക്കുകയോ ഇല്ല.', emergency:'അടിയന്തര കുറിപ്പ്', pain:'എനിക്ക് വേദനയുണ്ട്', headache:'എനിക്ക് തലവേദനയുണ്ട്', stomach:'എനിക്ക് വയറുവേദനയുണ്ട്', fever:'എനിക്ക് പനിയുണ്ട്', dizzy:'എനിക്ക് തലകറങ്ങുന്നു', nausea:'എനിക്ക് ഛർദ്ദി തോന്നുന്നു', help:'എനിക്ക് സഹായം വേണം', doctor:'എനിക്ക് ഡോക്ടറെ വേണം', breathing:'എനിക്ക് ശ്വസിക്കാൻ ബുദ്ധിമുട്ടുണ്ട്', allergy:'എനിക്ക് അലർജിയുണ്ട്', water:'എനിക്ക് വെള്ളം വേണം', unwell:'എനിക്ക് സുഖമില്ല' },
  Bengali: { hospital:'হাসপাতালের রিপোর্ট', intro:'যে রোগী কথা বলতে পারেন না তাঁর জন্য। ভাষা বেছে নিন। ক্যামেরা হাত ট্র্যাক করে; সাইনকে লেখায় বদলাতে প্রশিক্ষিত ISL মডেল দরকার।', camera:'ক্যামেরা ও হাত ট্র্যাকিং চালু করুন', stop:'ক্যামেরা বন্ধ করুন', cameraTitle:'হাত ট্র্যাকিং প্রিভিউ', cameraSub:'হাত ট্র্যাক করতে ক্যামেরা চালু করুন', quick:'দ্রুত হাসপাতাল বাক্য', quickHelp:'রোগী যে বার্তাটি জানাতে চান তা বেছে নিন। এগুলি বিকল্প ইনপুট, AI-চেনা সাইন নয়।', clear:'উপসর্গ মুছুন', speech:'ঐচ্ছিক ভয়েস ইনপুট', review:'জমা দেওয়ার আগে পর্যালোচনা করুন', details:'রোগীর বিবরণ ও উপসর্গ', fictional:'হ্যাকাথন ডেমোর জন্য কাল্পনিক তথ্য ব্যবহার করুন।', patient:'রোগীর নাম (ঐচ্ছিক)', age:'বয়স (ঐচ্ছিক)', language:'পছন্দের ভাষা', symptoms:'উপসর্গ / বার্তা *', symptomPlaceholder:'বাক্য বেছে নিন বা বার্তা লিখুন…', urgency:'নির্বাচিত জরুরিতা', duration:'কতক্ষণ ধরে?', durationPlaceholder:'যেমন আজ সকাল থেকে', allergies:'পরিচিত অ্যালার্জি (ঐচ্ছিক)', allergyPlaceholder:'অজানা / নেই / বিবরণ', notes:'অতিরিক্ত নোট (ঐচ্ছিক)', notesPlaceholder:'রোগী যে অন্য তথ্য জানাতে চান', read:'রিপোর্ট পড়ে শোনান', submit:'নিশ্চিত করে জমা দিন', saving:'সংরক্ষণ হচ্ছে…', privacy:'গোপনীয়তা: ক্যামেরার ফ্রেম এই ব্রাউজারেই প্রক্রিয়াকৃত হয়; আপলোড বা সংরক্ষণ করা হয় না।', emergency:'জরুরি নোট', pain:'আমার ব্যথা হচ্ছে', headache:'আমার মাথা ব্যথা করছে', stomach:'আমার পেটে ব্যথা হচ্ছে', fever:'আমার জ্বর হয়েছে', dizzy:'আমার মাথা ঘুরছে', nausea:'আমার বমি বমি লাগছে', help:'আমার সাহায্য দরকার', doctor:'আমার ডাক্তার দরকার', breathing:'আমার শ্বাস নিতে কষ্ট হচ্ছে', allergy:'আমার অ্যালার্জি আছে', water:'আমার জল দরকার', unwell:'আমার শরীর ভালো লাগছে না' },
 };
Object.assign(I18N, {
  Kannada: { ...I18N.English, hospital:'ಆಸ್ಪತ್ರೆ ವರದಿ', camera:'ಕ್ಯಾಮೆರಾ ಮತ್ತು ಕೈ ಟ್ರ್ಯಾಕಿಂಗ್ ಪ್ರಾರಂಭಿಸಿ', stop:'ಕ್ಯಾಮೆರಾ ನಿಲ್ಲಿಸಿ', quick:'ತ್ವರಿತ ಆಸ್ಪತ್ರೆ ವಾಕ್ಯಗಳು', clear:'ಲಕ್ಷಣಗಳನ್ನು ತೆರವುಗೊಳಿಸಿ', speech:'ಐಚ್ಛಿಕ ಧ್ವನಿ ಇನ್‌ಪುಟ್', review:'ಸಲ್ಲಿಸುವ ಮೊದಲು ಪರಿಶೀಲಿಸಿ', details:'ರೋಗಿಯ ವಿವರಗಳು ಮತ್ತು ಲಕ್ಷಣಗಳು', patient:'ರೋಗಿಯ ಹೆಸರು (ಐಚ್ಛಿಕ)', age:'ವಯಸ್ಸು (ಐಚ್ಛಿಕ)', language:'ಆದ್ಯತೆಯ ಭಾಷೆ', symptoms:'ಲಕ್ಷಣಗಳು / ಸಂದೇಶ *', urgency:'ಆಯ್ದ ತುರ್ತು ಮಟ್ಟ', duration:'ಎಷ್ಟು ಸಮಯದಿಂದ?', allergies:'ತಿಳಿದಿರುವ ಅಲರ್ಜಿ (ಐಚ್ಛಿಕ)', notes:'ಹೆಚ್ಚುವರಿ ಟಿಪ್ಪಣಿಗಳು (ಐಚ್ಛಿಕ)', read:'ವರದಿಯನ್ನು ಓದಿ ಕೇಳಿಸಿ', submit:'ದೃಢೀಕರಿಸಿ ಸಲ್ಲಿಸಿ', pain:'ನನಗೆ ನೋವು ಇದೆ', headache:'ನನಗೆ ತಲೆನೋವು ಇದೆ', stomach:'ನನಗೆ ಹೊಟ್ಟೆ ನೋವು ಇದೆ', fever:'ನನಗೆ ಜ್ವರ ಇದೆ', dizzy:'ನನಗೆ ತಲೆಸುತ್ತುತ್ತಿದೆ', nausea:'ವಾಕರಿಕೆ ಆಗುತ್ತಿದೆ', help:'ನನಗೆ ಸಹಾಯ ಬೇಕು', doctor:'ನನಗೆ ವೈದ್ಯರು ಬೇಕು', breathing:'ಉಸಿರಾಡಲು ತೊಂದರೆ ಇದೆ', allergy:'ನನಗೆ ಅಲರ್ಜಿ ಇದೆ', water:'ನನಗೆ ನೀರು ಬೇಕು', unwell:'ನನಗೆ ಆರೋಗ್ಯ ಸರಿಯಿಲ್ಲ' },
  Marathi: { ...I18N.English, hospital:'रुग्णालय अहवाल', camera:'कॅमेरा आणि हात ट्रॅकिंग सुरू करा', stop:'कॅमेरा थांबवा', quick:'रुग्णालयासाठी झटपट वाक्ये', clear:'लक्षणे काढून टाका', speech:'पर्यायी आवाज इनपुट', review:'सबमिट करण्यापूर्वी तपासा', details:'रुग्णाची माहिती आणि लक्षणे', patient:'रुग्णाचे नाव (ऐच्छिक)', age:'वय (ऐच्छिक)', language:'प्राधान्याची भाषा', symptoms:'लक्षणे / संदेश *', urgency:'निवडलेली तातडी', duration:'किती वेळापासून?', allergies:'माहित असलेल्या अॅलर्जी (ऐच्छिक)', notes:'अतिरिक्त नोंदी (ऐच्छिक)', read:'अहवाल मोठ्याने वाचा', submit:'पुष्टी करून सबमिट करा', pain:'मला वेदना होत आहेत', headache:'माझे डोके दुखत आहे', stomach:'माझे पोट दुखत आहे', fever:'मला ताप आहे', dizzy:'मला चक्कर येत आहे', nausea:'मळमळ होत आहे', help:'मला मदत हवी आहे', doctor:'मला डॉक्टर हवेत', breathing:'मला श्वास घेण्यास त्रास होतो', allergy:'मला अॅलर्जी आहे', water:'मला पाणी हवे आहे', unwell:'मला बरे वाटत नाही' },
  Gujarati: { ...I18N.English, hospital:'હોસ્પિટલ રિપોર્ટ', camera:'કેમેરા અને હાથ ટ્રેકિંગ શરૂ કરો', stop:'કેમેરા બંધ કરો', quick:'ઝડપી હોસ્પિટલ વાક્યો', clear:'લક્ષણો સાફ કરો', speech:'વૈકલ્પિક અવાજ ઇનપુટ', review:'સબમિટ કરતા પહેલાં તપાસો', details:'દર્દીની વિગતો અને લક્ષણો', patient:'દર્દીનું નામ (વૈકલ્પિક)', age:'ઉંમર (વૈકલ્પિક)', language:'પસંદગીની ભાષા', symptoms:'લક્ષણો / સંદેશ *', urgency:'પસંદ કરેલી તાત્કાલિકતા', duration:'કેટલા સમયથી?', allergies:'જાણીતી એલર્જી (વૈકલ્પિક)', notes:'વધારાની નોંધ (વૈકલ્પિક)', read:'રિપોર્ટ વાંચીને સંભળાવો', submit:'ખાતરી કરીને સબમિટ કરો', pain:'મને દુખાવો છે', headache:'મારું માથું દુખે છે', stomach:'મારું પેટ દુખે છે', fever:'મને તાવ છે', dizzy:'મને ચક્કર આવે છે', nausea:'મને ઊબકા આવે છે', help:'મને મદદ જોઈએ', doctor:'મને ડૉક્ટર જોઈએ', breathing:'મને શ્વાસ લેવામાં તકલીફ છે', allergy:'મને એલર્જી છે', water:'મને પાણી જોઈએ', unwell:'મને સારું લાગતું નથી' },
  Punjabi: { ...I18N.English, hospital:'ਹਸਪਤਾਲ ਰਿਪੋਰਟ', camera:'ਕੈਮਰਾ ਅਤੇ ਹੱਥ ਟ੍ਰੈਕਿੰਗ ਸ਼ੁਰੂ ਕਰੋ', stop:'ਕੈਮਰਾ ਬੰਦ ਕਰੋ', quick:'ਹਸਪਤਾਲ ਲਈ ਤੁਰੰਤ ਵਾਕ', clear:'ਲੱਛਣ ਮਿਟਾਓ', speech:'ਵਿਕਲਪਿਕ ਆਵਾਜ਼ ਇਨਪੁੱਟ', review:'ਜਮ੍ਹਾਂ ਕਰਨ ਤੋਂ ਪਹਿਲਾਂ ਜਾਂਚੋ', details:'ਮਰੀਜ਼ ਦੇ ਵੇਰਵੇ ਅਤੇ ਲੱਛਣ', patient:'ਮਰੀਜ਼ ਦਾ ਨਾਮ (ਵਿਕਲਪਿਕ)', age:'ਉਮਰ (ਵਿਕਲਪਿਕ)', language:'ਪਸੰਦੀਦਾ ਭਾਸ਼ਾ', symptoms:'ਲੱਛਣ / ਸੁਨੇਹਾ *', urgency:'ਚੁਣੀ ਗਈ ਤਤਕਾਲਤਾ', duration:'ਕਿੰਨੇ ਸਮੇਂ ਤੋਂ?', allergies:'ਜਾਣੀਆਂ ਐਲਰਜੀਆਂ (ਵਿਕਲਪਿਕ)', notes:'ਵਾਧੂ ਨੋਟ (ਵਿਕਲਪਿਕ)', read:'ਰਿਪੋਰਟ ਉੱਚੀ ਆਵਾਜ਼ ਵਿੱਚ ਪੜ੍ਹੋ', submit:'ਪੁਸ਼ਟੀ ਕਰਕੇ ਜਮ੍ਹਾਂ ਕਰੋ', pain:'ਮੈਨੂੰ ਦਰਦ ਹੈ', headache:'ਮੇਰਾ ਸਿਰ ਦਰਦ ਕਰਦਾ ਹੈ', stomach:'ਮੇਰਾ ਪੇਟ ਦਰਦ ਕਰਦਾ ਹੈ', fever:'ਮੈਨੂੰ ਬੁਖਾਰ ਹੈ', dizzy:'ਮੈਨੂੰ ਚੱਕਰ ਆ ਰਹੇ ਹਨ', nausea:'ਮੈਨੂੰ ਮਤਲੀ ਆ ਰਹੀ ਹੈ', help:'ਮੈਨੂੰ ਮਦਦ ਚਾਹੀਦੀ ਹੈ', doctor:'ਮੈਨੂੰ ਡਾਕਟਰ ਚਾਹੀਦਾ ਹੈ', breathing:'ਮੈਨੂੰ ਸਾਹ ਲੈਣ ਵਿੱਚ ਮੁਸ਼ਕਲ ਹੈ', allergy:'ਮੈਨੂੰ ਐਲਰਜੀ ਹੈ', water:'ਮੈਨੂੰ ਪਾਣੀ ਚਾਹੀਦਾ ਹੈ', unwell:'ਮੇਰੀ ਤਬੀਅਤ ਠੀਕ ਨਹੀਂ' },
  Odia: { ...I18N.English, hospital:'ହସ୍ପିଟାଲ ରିପୋର୍ଟ', camera:'କ୍ୟାମେରା ଓ ହାତ ଟ୍ରାକିଂ ଆରମ୍ଭ କରନ୍ତୁ', stop:'କ୍ୟାମେରା ବନ୍ଦ କରନ୍ତୁ', quick:'ତୁରନ୍ତ ହସ୍ପିଟାଲ ବାକ୍ୟ', clear:'ଲକ୍ଷଣ ହଟାନ୍ତୁ', speech:'ଇଚ୍ଛାଧୀନ ଭଏସ୍ ଇନପୁଟ୍', review:'ଦାଖଲ ପୂର୍ବରୁ ଯାଞ୍ଚ କରନ୍ତୁ', details:'ରୋଗୀ ବିବରଣୀ ଓ ଲକ୍ଷଣ', patient:'ରୋଗୀଙ୍କ ନାମ (ଇଚ୍ଛାଧୀନ)', age:'ବୟସ (ଇଚ୍ଛାଧୀନ)', language:'ପସନ୍ଦର ଭାଷା', symptoms:'ଲକ୍ଷଣ / ବାର୍ତ୍ତା *', urgency:'ଚୟନ କରାଯାଇଥିବା ଜରୁରୀକାଳୀନତା', duration:'କେତେ ସମୟ ହେଲା?', allergies:'ଜଣାଶୁଣା ଆଲର୍ଜି (ଇଚ୍ଛାଧୀନ)', notes:'ଅତିରିକ୍ତ ଟିପ୍ପଣୀ (ଇଚ୍ଛାଧୀନ)', read:'ରିପୋର୍ଟ ପଢ଼ି ଶୁଣାନ୍ତୁ', submit:'ନିଶ୍ଚିତ କରି ଦାଖଲ କରନ୍ତୁ', pain:'ମୋତେ ଯନ୍ତ୍ରଣା ହେଉଛି', headache:'ମୋର ମୁଣ୍ଡ ବିନ୍ଧୁଛି', stomach:'ମୋର ପେଟ ବିନ୍ଧୁଛି', fever:'ମୋତେ ଜ୍ୱର ହୋଇଛି', dizzy:'ମୋତେ ମୁଣ୍ଡ ବୁଲାଉଛି', nausea:'ମୋତେ ବାନ୍ତି ଲାଗୁଛି', help:'ମୋତେ ସାହାଯ୍ୟ ଦରକାର', doctor:'ମୋତେ ଡାକ୍ତର ଦରକାର', breathing:'ମୋତେ ଶ୍ୱାସ ନେବାରେ କଷ୍ଟ ହେଉଛି', allergy:'ମୋର ଆଲର୍ଜି ଅଛି', water:'ମୋତେ ପାଣି ଦରକାର', unwell:'ମୋ ଦେହ ଭଲ ଲାଗୁନାହିଁ' },
  Assamese: { ...I18N.English, hospital:'চিকিৎসালয়ৰ প্ৰতিবেদন', camera:'কেমেৰা আৰু হাত ট্ৰেকিং আৰম্ভ কৰক', stop:'কেমেৰা বন্ধ কৰক', quick:'চিকিৎসালয়ৰ দ্ৰুত বাক্য', clear:'লক্ষণ মচক', speech:'ঐচ্ছিক কণ্ঠ ইনপুট', review:'দাখিল কৰাৰ আগতে পৰীক্ষা কৰক', details:'ৰোগীৰ বিৱৰণ আৰু লক্ষণ', patient:'ৰোগীৰ নাম (ঐচ্ছিক)', age:'বয়স (ঐচ্ছিক)', language:'পছন্দৰ ভাষা', symptoms:'লক্ষণ / বাৰ্তা *', urgency:'নিৰ্বাচিত জৰুৰিতা', duration:'কিমান সময়ৰ পৰা?', allergies:'জনাজাত এলাৰ্জি (ঐচ্ছিক)', notes:'অতিৰিক্ত টোকা (ঐচ্ছিক)', read:'প্ৰতিবেদনটো পঢ়ি শুনাওক', submit:'নিশ্চিত কৰি দাখিল কৰক', pain:'মোৰ বিষ হৈছে', headache:'মোৰ মূৰৰ বিষ হৈছে', stomach:'মোৰ পেটৰ বিষ হৈছে', fever:'মোৰ জ্বৰ হৈছে', dizzy:'মোৰ মূৰ ঘূৰিছে', nausea:'মোৰ বমি বমি লাগিছে', help:'মোক সহায় লাগে', doctor:'মোক চিকিৎসক লাগে', breathing:'মোৰ উশাহ লোৱাত অসুবিধা হৈছে', allergy:'মোৰ এলাৰ্জি আছে', water:'মোক পানী লাগে', unwell:'মোৰ গা ভাল লগা নাই' },
  Urdu: { ...I18N.English, hospital:'ہسپتال کی رپورٹ', camera:'کیمرہ اور ہاتھوں کی ٹریکنگ شروع کریں', stop:'کیمرہ بند کریں', quick:'ہسپتال کے فوری جملے', clear:'علامات صاف کریں', speech:'اختیاری آواز کا ان پٹ', review:'جمع کرنے سے پہلے جائزہ لیں', details:'مریض کی تفصیلات اور علامات', patient:'مریض کا نام (اختیاری)', age:'عمر (اختیاری)', language:'پسندیدہ زبان', symptoms:'علامات / پیغام *', urgency:'منتخب فوری نوعیت', duration:'کتنی دیر سے؟', allergies:'معلوم الرجی (اختیاری)', notes:'اضافی نوٹس (اختیاری)', read:'رپورٹ بلند آواز سے پڑھیں', submit:'تصدیق کرکے جمع کریں', pain:'مجھے درد ہے', headache:'میرے سر میں درد ہے', stomach:'میرے پیٹ میں درد ہے', fever:'مجھے بخار ہے', dizzy:'مجھے چکر آ رہے ہیں', nausea:'مجھے متلی ہو رہی ہے', help:'مجھے مدد چاہیے', doctor:'مجھے ڈاکٹر چاہیے', breathing:'مجھے سانس لینے میں دشواری ہے', allergy:'مجھے الرجی ہے', water:'مجھے پانی چاہیے', unwell:'میری طبیعت ٹھیک نہیں' },
});
const LANGUAGE_ALIASES = { 'தமிழ் (Tamil)':'Tamil', 'हिन्दी (Hindi)':'Hindi', 'తెలుగు (Telugu)':'Telugu', 'ಕನ್ನಡ (Kannada)':'Kannada', 'മലയാളം (Malayalam)':'Malayalam', 'বাংলা (Bengali)':'Bengali', 'मराठी (Marathi)':'Marathi', 'ગુજરાતી (Gujarati)':'Gujarati', 'ਪੰਜਾਬੀ (Punjabi)':'Punjabi', 'ଓଡ଼ିଆ (Odia)':'Odia', 'অসমীয়া (Assamese)':'Assamese', 'اردو (Urdu)':'Urdu', 'संस्कृतम् (Sanskrit)':'Sanskrit' };
function languageKey(value) { return LANGUAGE_ALIASES[value] || value || 'English'; }
function localeFor(value) { return LANGUAGES.find(item => item.value === value || item.name === value)?.locale || 'en-IN'; }

function speak(text) {
  if (!('speechSynthesis' in window)) {
    window.alert('Speech playback is not available in this browser. Try a current Chrome or Edge browser.');
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 0.9;
  window.speechSynthesis.speak(utterance);
}

function formatDate(value) {
  try { return new Date(value).toLocaleString(); } catch { return value; }
}

function StaffPage({ apiBase }) {
  const token = decodeURIComponent(window.location.pathname.split('/').filter(Boolean)[1] || '');
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState('Loading profile…');

  useEffect(() => {
    let cancelled = false;
    fetch(`${apiBase}/api/profiles/${encodeURIComponent(token)}`)
      .then(async (r) => {
        const body = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(body.detail || 'Could not load this profile.');
        return body;
      })
      .then((data) => { if (!cancelled) { setProfile(data); setError(''); } })
      .catch((e) => { if (!cancelled) { setProfile(null); setError(e.message); } });
    return () => { cancelled = true; };
  }, [apiBase, token]);

  if (!profile) return <main className="narrow"><p className="eyebrow">STAFF VIEW</p><h1>Accessible profile</h1><p role="status" className="notice">{error}</p><a href="/">Back to demo home</a></main>;
  const spoken = `Accessible profile for ${profile.name}. Preferred language: ${profile.preferred_language}. Support notes: ${profile.accessibility_notes || 'No additional notes'}. Link expires at ${formatDate(profile.expires_at)}.`;
  return <main className="narrow"><p className="eyebrow">STAFF VIEW · QR ACCESS</p><h1>Accessible profile</h1><p className="notice">This page was opened from a temporary QR link. Share only with authorised demo participants.</p><section className="panel"><h2>{profile.name}</h2><p><strong>Preferred language:</strong> {profile.preferred_language}</p><p><strong>Accessibility notes:</strong> {profile.accessibility_notes || 'No additional notes provided.'}</p><p className="muted"><strong>Link expires:</strong> {formatDate(profile.expires_at)}</p><button onClick={() => speak(spoken)}>🔊 Read profile aloud</button></section><a href="/">Back to demo home</a></main>;
}

function CreateProfile({ apiBase }) {
  const [name, setName] = useState('Demo Visitor');
  const [language, setLanguage] = useState('English');
  const [notes, setNotes] = useState('Please speak clearly and read information aloud.');
  const [minutes, setMinutes] = useState('30');
  const [qrBase, setQrBase] = useState(window.location.origin);
  const [created, setCreated] = useState(null);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const qrUrl = created ? `${qrBase.replace(/\/$/, '')}/staff/${created.token}` : '';

  async function create() {
    setBusy(true); setMessage(''); setCreated(null);
    try {
      const response = await fetch(`${apiBase}/api/profiles`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, preferred_language: language, accessibility_notes: notes, expires_in_minutes: Number(minutes) }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.detail || 'Could not create profile. Check that the backend is running.');
      setCreated(body);
      setMessage('Profile created. Scan this QR using another device.');
    } catch (e) { setMessage(e.message); }
    finally { setBusy(false); }
  }

  async function revoke() {
    if (!created) return;
    try {
      const response = await fetch(`${apiBase}/api/profiles/${encodeURIComponent(created.token)}`, { method: 'DELETE' });
      if (!response.ok) throw new Error('Could not revoke profile.');
      setMessage('QR link revoked. Refresh the staff page to verify that access is denied.');
    } catch (e) { setMessage(e.message); }
  }

  return <div className="layout"><section className="panel"><p className="eyebrow">TEMPORARY ACCESS</p><h2>Create an accessibility profile</h2><p className="muted">Use fictional information for the hackathon demonstration.</p><label>Display name<input value={name} onChange={e => setName(e.target.value)} maxLength="80" required /></label><label>Preferred language<input value={language} onChange={e => setLanguage(e.target.value)} maxLength="40" /></label><label>Accessibility notes<textarea value={notes} onChange={e => setNotes(e.target.value)} maxLength="500" rows="3" /></label><label>Link expires in<select value={minutes} onChange={e => setMinutes(e.target.value)}><option value="1">1 minute (expiry test)</option><option value="5">5 minutes</option><option value="30">30 minutes</option><option value="60">1 hour</option><option value="1440">24 hours</option></select></label><label>QR link base URL<input value={qrBase} onChange={e => setQrBase(e.target.value)} spellCheck="false" /><span className="hint">For a second device, use your laptop's Wi-Fi IPv4 address, for example http://192.168.1.15:5173. Do not use localhost in a phone QR.</span></label><button onClick={create} disabled={busy || !name.trim() || !qrBase.trim()}>{busy ? 'Creating…' : 'Create profile + QR'}</button>{message && <p role="status" className="status">{message}</p>}</section>
  <section className="panel qr-panel"><h2>Temporary QR</h2>{created ? <><div className="qr"><QRCodeSVG value={qrUrl} size={220} level="M" includeMargin /></div><p className="hint break">{qrUrl}</p><p><strong>Expires:</strong> {formatDate(created.expires_at)}</p><div className="button-row"><button className="secondary" onClick={() => { navigator.clipboard?.writeText(qrUrl); setMessage('QR link copied if clipboard permission is available.'); }}>Copy link</button><button className="danger" onClick={revoke}>Revoke link</button></div></> : <p className="muted">Your QR code will appear here after you create a profile.</p>}</section></div>;
}

function BillingDemo() {
  const [paymentMessage, setPaymentMessage] = useState('');
  const billText = 'Fictional invoice. Invoice number DEMO 1042. Item: reusable water bottle, quantity one, 350 rupees. Delivery charge, 40 rupees. Total amount, 390 rupees. Payment status: unpaid demo invoice.';
  return <section className="panel"><p className="eyebrow">ACCESSIBLE BILL READING</p><h2>Fictional invoice</h2><p className="muted">No real merchant, transaction, or personal data is used.</p><div className="invoice"><div className="invoice-head"><span>DEMO STORE</span><span>INVOICE #DEMO-1042</span></div><div className="invoice-row"><span>Reusable water bottle × 1</span><strong>₹350.00</strong></div><div className="invoice-row"><span>Delivery charge</span><strong>₹40.00</strong></div><div className="invoice-row total"><span>Total to pay</span><strong>₹390.00</strong></div><p className="muted">Status: Not paid</p></div><div className="button-row"><button onClick={() => speak(billText)}>🔊 Read bill aloud</button><button className="secondary" onClick={() => setPaymentMessage('Demo only: no payment was taken. A real payment integration is not connected.')}>Confirm demo payment</button></div>{paymentMessage && <p role="status" className="status">{paymentMessage}</p>}<p className="hint">Never speak, store, or request a user's UPI PIN, OTP, password, or card security code in this demo.</p></section>;
}

function ReminderDemo() {
  const [medicine, setMedicine] = useState('Medicine from my prescription');
  const [time, setTime] = useState('20:00');
  const [reminders, setReminders] = useState([]);
  const [message, setMessage] = useState('');
  function addReminder(e) {
    e.preventDefault();
    if (!medicine.trim()) return;
    setReminders(old => [...old, { medicine: medicine.trim(), time }]);
    setMessage('Reminder saved in this page for demonstration only. No notification will be sent.');
  }
  return <section className="panel"><p className="eyebrow">OPTIONAL PROTOTYPE</p><h2>Medicine reminder</h2><p className="muted">Enter only instructions already provided by a clinician or pharmacist. This tool does not recommend medicines or doses.</p><form onSubmit={addReminder}><label>Reminder label<input value={medicine} onChange={e => setMedicine(e.target.value)} maxLength="100" /></label><label>Reminder time<input type="time" value={time} onChange={e => setTime(e.target.value)} required /></label><button type="submit">Save demo reminder</button></form>{message && <p role="status" className="status">{message}</p>}{reminders.length > 0 && <div><h3>Saved on this page</h3><ul>{reminders.map((r, i) => <li key={`${r.time}-${i}`}>{r.time} — {r.medicine}</li>)}</ul></div>}</section>;
}

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const existing = [...document.scripts].find(s => s.src === src);
    if (existing) {
      if (existing.dataset.loaded === 'true') return resolve();
      existing.addEventListener('load', resolve, { once: true });
      existing.addEventListener('error', reject, { once: true });
      return;
    }
    const script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.onload = () => { script.dataset.loaded = 'true'; resolve(); };
    script.onerror = () => reject(new Error(`Could not load camera tracking library: ${src}`));
    document.head.appendChild(script);
  });
}

function HospitalReport({ apiBase }) {
  const [patientName, setPatientName] = useState('');
  const [age, setAge] = useState('');
  const [language, setLanguage] = useState('Tamil');
  const [customLanguage, setCustomLanguage] = useState('');
  const ui = I18N[languageKey(language)] || I18N.English;
  const tr = (key) => ui[key] || I18N.English[key] || key;
  const [severity, setSeverity] = useState('Moderate');
  const [duration, setDuration] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [allergies, setAllergies] = useState('');
  const [notes, setNotes] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [savedReport, setSavedReport] = useState(null);
  const [cameraStatus, setCameraStatus] = useState('Camera is off. Start it when you are ready.');
  const [handsCount, setHandsCount] = useState(0);
  const [tracking, setTracking] = useState(false);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const trackerRef = useRef(null);
  const runningRef = useRef(false);

  const phrases = [
    ['pain', tr('pain')], ['headache', tr('headache')], ['stomach', tr('stomach')], ['fever', tr('fever')],
    ['dizzy', tr('dizzy')], ['nausea', tr('nausea')], ['help', tr('help')], ['doctor', tr('doctor')],
    ['breathing', tr('breathing')], ['allergy', tr('allergy')], ['water', tr('water')], ['unwell', tr('unwell')]
  ];
  function addPhrase(phrase) {
    setSymptoms(old => old.trim() ? `${old.trim()}${old.trim().endsWith('.') ? '' : ';'} ${phrase}` : phrase);
    setSavedReport(null);
    setMessage('Phrase added. Please review it before submitting.');
  }

  async function startCamera() {
    setCameraStatus('Requesting camera permission…');
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error('Camera access needs localhost or an HTTPS website in a supported browser.');
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }, audio: false });
      streamRef.current = stream;
      const video = videoRef.current;
      if (!video) throw new Error('Camera preview is not ready.');
      video.srcObject = stream;
      await video.play();
      setCameraStatus('Camera is on. Loading hand-landmark tracking…');
      await loadScript('https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js');
      await loadScript('https://cdn.jsdelivr.net/npm/@mediapipe/drawing_utils/drawing_utils.js');
      if (!window.Hands) throw new Error('MediaPipe did not initialize. Use the hospital phrase buttons while checking network access.');
      const hands = new window.Hands({ locateFile: file => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}` });
      hands.setOptions({ maxNumHands: 2, modelComplexity: 1, selfieMode: true, minDetectionConfidence: 0.6, minTrackingConfidence: 0.55 });
      hands.onResults(results => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const width = video.videoWidth || 640;
        const height = video.videoHeight || 480;
        if (canvas.width !== width || canvas.height !== height) { canvas.width = width; canvas.height = height; }
        ctx.save(); ctx.clearRect(0, 0, width, height);
        const points = results.multiHandLandmarks || [];
        setHandsCount(points.length);
        points.forEach(landmarks => {
          if (window.drawConnectors && window.HAND_CONNECTIONS) window.drawConnectors(ctx, landmarks, window.HAND_CONNECTIONS, { color: '#5eead4', lineWidth: 4 });
          if (window.drawLandmarks) window.drawLandmarks(ctx, landmarks, { color: '#fef08a', lineWidth: 1, radius: 3 });
        });
        ctx.restore();
      });
      trackerRef.current = hands;
      runningRef.current = true;
      setTracking(true);
      setCameraStatus('Hand tracking is live. It tracks hand landmarks; automatic ISL meaning recognition is not yet connected.');
      const processFrame = async () => {
        if (!runningRef.current) return;
        try { if (video.readyState >= 2 && trackerRef.current) await trackerRef.current.send({ image: video }); } catch (err) { /* keep preview responsive */ }
        if (runningRef.current) requestAnimationFrame(processFrame);
      };
      requestAnimationFrame(processFrame);
    } catch (err) {
      setCameraStatus(`${err.message || 'Could not start the camera.'} You can still create the report using the buttons below.`);
      setTracking(false);
      if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  }

  function stopCamera() {
    runningRef.current = false;
    setTracking(false);
    setHandsCount(0);
    if (trackerRef.current?.close) trackerRef.current.close();
    trackerRef.current = null;
    if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    const ctx = canvasRef.current?.getContext('2d');
    if (ctx && canvasRef.current) ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    setCameraStatus('Camera stopped. No camera video is saved by this page.');
  }
  useEffect(() => () => {
    runningRef.current = false;
    if (trackerRef.current?.close) trackerRef.current.close();
    if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
  }, []);

  function startSpeechInput() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { setMessage('Speech recognition is not available in this browser. Use the phrase buttons or type in the report.'); return; }
    const recognition = new SpeechRecognition();
    recognition.lang = localeFor(language);
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    setMessage('Listening for speech input… (optional; not needed for a non-speaking patient)');
    recognition.onresult = event => {
      const text = event.results?.[0]?.[0]?.transcript || '';
      if (text) setSymptoms(old => old.trim() ? `${old.trim()}; ${text}` : text);
      setMessage(text ? `Speech added to report: ${text}` : 'No speech was captured.');
    };
    recognition.onerror = event => setMessage(`Speech input error: ${event.error}. You can type or use the phrase buttons.`);
    recognition.start();
  }

  const reportText = `${tr('hospital')}. ${tr('patient')}: ${patientName || 'Not provided'}. ${tr('age')}: ${age || 'Not provided'}. ${tr('language')}: ${language === 'Other' ? (customLanguage || 'Other') : language}. ${tr('urgency')}: ${severity}. ${tr('duration')}: ${duration || 'Not provided'}. ${tr('symptoms')}: ${symptoms || 'Not provided'}. ${tr('allergies')}: ${allergies || 'Not provided'}. ${tr('notes')}: ${notes || 'None'}. Please have clinical staff assess this report.`;
  async function submitReport(e) {
    e.preventDefault();
    if (!symptoms.trim()) { setMessage('Add a symptom or communication phrase before submitting.'); return; }
    setBusy(true); setMessage(''); setSavedReport(null);
    try {
      const response = await fetch(`${apiBase}/api/reports`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ patient_name: patientName || 'Not provided', age: age ? Number(age) : null, language: language === 'Other' ? (customLanguage.trim() || 'Other') : language, severity, duration, symptoms, allergies, notes, communication_method: 'Accessible phrase buttons / keyboard input; camera hand tracking only' })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.detail || 'Could not save the report. Check whether the backend is running.');
      setSavedReport(data);
      setMessage('Report saved in the local demo database. Please hand it to qualified hospital staff for assessment.');
    } catch (err) { setMessage(err.message || 'Could not submit this report.'); }
    finally { setBusy(false); }
  }

  return <div className="hospital-grid" dir={language === 'Urdu' ? 'rtl' : 'ltr'}>
    <section className="panel">
      <p className="eyebrow">PATIENT COMMUNICATION · ISL SUPPORT</p>
      <h2>{tr('hospital')}</h2>
      <p className="muted">{tr('intro')}</p>
      <div className="camera-wrap">
        <div className="camera-stage">
          <video ref={videoRef} className="camera-video" playsInline muted aria-label="Live hand camera preview" />
          <canvas ref={canvasRef} className="camera-overlay" aria-hidden="true" />
          {!tracking && <div className="camera-placeholder"><span aria-hidden="true">✋</span><strong>{tr('cameraTitle')}</strong><small>{tr('cameraSub')}</small></div>}
        </div>
        <div className="camera-controls"><button type="button" onClick={tracking ? stopCamera : startCamera}>{tracking ? tr('stop') : tr('camera')}</button>{tracking && <span className="hand-count" role="status">{handsCount} hand{handsCount === 1 ? '' : 's'} detected</span>}</div>
        <p className="hint" role="status">{cameraStatus}</p>
        <p className="hint">Privacy: camera frames are processed in this browser and are not uploaded or stored by this app. This is a hackathon demo, not a certified medical translator.</p>
      </div>
      <div className="phrases-block">
        <h3>{tr('quick')}</h3>
        <p className="muted">{tr('quickHelp')}</p>
        <div className="phrase-grid">{phrases.map(([key, phrase]) => <button type="button" className="phrase-button" key={key} onClick={() => addPhrase(phrase)}>{phrase}</button>)}</div>
        <div className="button-row"><button type="button" className="secondary" onClick={() => setSymptoms('')}>{tr('clear')}</button><button type="button" className="secondary" onClick={startSpeechInput}>🎙 {tr('speech')}</button></div>
      </div>
    </section>
    <section className="panel">
      <p className="eyebrow">{tr('review')}</p>
      <h2>{tr('details')}</h2>
      <p className="muted">{tr('fictional')}</p>
      <form onSubmit={submitReport}>
        <label>{tr('patient')}<input value={patientName} onChange={e => setPatientName(e.target.value)} maxLength="80" placeholder="Patient or demo name" /></label>
        <div className="form-two"><label>{tr('age')}<input type="number" min="0" max="120" value={age} onChange={e => setAge(e.target.value)} /></label><label>{tr('language')}<select value={language} onChange={e => setLanguage(e.target.value)}><option value="English">English</option><option value="Tamil">தமிழ் (Tamil)</option><option value="Hindi">हिन्दी (Hindi)</option><option value="Telugu">తెలుగు (Telugu)</option><option value="Kannada">ಕನ್ನಡ (Kannada)</option><option value="Malayalam">മലയാളം (Malayalam)</option><option value="Bengali">বাংলা (Bengali)</option><option value="Marathi">मराठी (Marathi)</option><option value="Gujarati">ગુજરાતી (Gujarati)</option><option value="Punjabi">ਪੰਜਾਬੀ (Punjabi)</option><option value="Odia">ଓଡ଼ିଆ (Odia)</option><option value="Assamese">অসমীয়া (Assamese)</option><option value="Urdu">اردو (Urdu)</option><option value="Sanskrit">संस्कृतम् (Sanskrit)</option><option value="Other">Other / type language</option></select></label></div>{language === 'Other' && <label>Language name<input value={customLanguage} onChange={e => setCustomLanguage(e.target.value)} maxLength="60" placeholder="Type the patient's language" /></label>}
        <label>{tr('symptoms')}<textarea value={symptoms} onChange={e => { setSymptoms(e.target.value); setSavedReport(null); }} maxLength="2000" rows="4" required placeholder={tr('symptomPlaceholder')} /></label>
        <div className="form-two"><label>{tr('urgency')}<select value={severity} onChange={e => setSeverity(e.target.value)}><option>Mild</option><option>Moderate</option><option>Severe</option><option>Emergency</option></select></label><label>{tr('duration')}<input value={duration} onChange={e => setDuration(e.target.value)} maxLength="120" placeholder={tr('durationPlaceholder')} /></label></div>
        <label>{tr('allergies')}<input value={allergies} onChange={e => setAllergies(e.target.value)} maxLength="500" placeholder={tr('allergyPlaceholder')} /></label>
        <label>{tr('notes')}<textarea value={notes} onChange={e => setNotes(e.target.value)} maxLength="1500" rows="3" placeholder={tr('notesPlaceholder')} /></label>
        <div className="button-row"><button type="button" onClick={() => { const u = new SpeechSynthesisUtterance(reportText); u.lang = localeFor(language); u.rate = 0.9; window.speechSynthesis.cancel(); window.speechSynthesis.speak(u); }}>🔊 {tr('read')}</button><button type="submit" disabled={busy || !symptoms.trim()}>{busy ? tr('saving') : tr('submit')}</button></div>
      </form>
      {message && <p className="status" role="status">{message}</p>}
      {savedReport && <div className="saved-report"><strong>Saved report ID: {savedReport.report_id}</strong><p>Created: {formatDate(savedReport.created_at)}</p><p>Submission status: {savedReport.status}</p><p className="hint">This confirms local demo storage only. It is not a diagnosis or a substitute for emergency medical care.</p><button className="secondary" type="button" onClick={() => { navigator.clipboard?.writeText(reportText); setMessage('Report text copied if clipboard permission is available.'); }}>Copy report text</button></div>}
      <div className="urgent-note"><strong>{tr('emergency')}:</strong> If a patient has severe breathing difficulty, chest pain, loss of consciousness, or another immediate danger, contact local emergency services and clinical staff immediately. Do not wait for this demo form.</div>
    </section>
  </div>;
}


function Home() {
  const apiBase = useMemo(() => `${window.location.protocol}//${window.location.hostname}:8000`, []);
  const [tab, setTab] = useState('hospital');
  const [apiStatus, setApiStatus] = useState('checking');
  useEffect(() => { fetch(`${apiBase}/health`).then(r => { if (!r.ok) throw new Error(); return r.json(); }).then(() => setApiStatus('online')).catch(() => setApiStatus('offline')); }, [apiBase]);
  return <><header className="topbar"><div className="brand-mark">UM</div><div><p className="brand">UnderstandMe</p><p className="tagline">Accessible support, made clearer · Multilingual hospital communication</p></div><span className={`api-badge ${apiStatus}`}>API {apiStatus}</span></header><main className="container"><section className="hero"><p className="eyebrow">THE DIGITAL MINDS · HACKATHON DEMO</p><h1>Information should be accessible to everyone.</h1><p>Help patients who cannot speak communicate symptoms through an accessible hospital report workflow, with ISL-focused camera support and accessible fallback controls.</p></section><nav className="tabs" aria-label="Demo sections"><button className={tab === 'hospital' ? 'active' : ''} onClick={() => setTab('hospital')}>Hospital Report</button><button className={tab === 'profile' ? 'active' : ''} onClick={() => setTab('profile')}>QR Profile</button><button className={tab === 'billing' ? 'active' : ''} onClick={() => setTab('billing')}>Accessible Bill</button><button className={tab === 'reminder' ? 'active' : ''} onClick={() => setTab('reminder')}>Reminder</button></nav>{tab === 'hospital' ? <HospitalReport apiBase={apiBase} /> : tab === 'profile' ? <CreateProfile apiBase={apiBase} /> : tab === 'billing' ? <BillingDemo /> : <ReminderDemo />}<footer>Hackathon prototype · Use fictional data · Camera tracks hands but does not yet automatically translate ISL meaning · Browser speech depends on device support</footer></main></>;
}

export default function App() {
  const isStaffPath = window.location.pathname.startsWith('/staff/');
  const apiBase = `${window.location.protocol}//${window.location.hostname}:8000`;
  return isStaffPath ? <StaffPage apiBase={apiBase} /> : <Home />;
}
